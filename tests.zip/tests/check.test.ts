import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { beforeEach, afterEach, describe, expect, it } from 'vitest';
import { checkNodeWorkspaceDrift } from '../src/core/check.js';
import type { FleetNodeEnrollmentStore, ProjectWorkspaceSession } from '../src/types.js';

describe('checkNodeWorkspaceDrift', () => {
  let tempDir: string;
  let cwd: string;
  let homeDir: string;

  beforeEach(() => {
    tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'relay-doctor-check-'));
    cwd = path.join(tempDir, 'project');
    homeDir = path.join(tempDir, 'home');
    fs.mkdirSync(cwd, { recursive: true });
    fs.mkdirSync(homeDir, { recursive: true });
  });

  afterEach(() => {
    fs.rmSync(tempDir, { recursive: true, force: true });
  });

  function setupModernProject(pinData?: Partial<ProjectWorkspaceSession>) {
    const modernDir = path.join(cwd, '.agentworkforce', 'relay');
    fs.mkdirSync(modernDir, { recursive: true });
    if (pinData) {
      fs.writeFileSync(
        path.join(modernDir, 'workspace-key.json'),
        JSON.stringify({
          workspaceKey: 'rk_live_secretkey12345',
          ...pinData,
        })
      );
    }
  }

  function setupLegacyProject(files: Record<string, string> = {}) {
    const legacyDir = path.join(cwd, '.agent-relay');
    fs.mkdirSync(legacyDir, { recursive: true });
    for (const [name, content] of Object.entries(files)) {
      fs.writeFileSync(path.join(legacyDir, name), content);
    }
  }

  function setupFleetEnrollments(nodes: Record<string, any> = {}) {
    const homeRelay = path.join(homeDir, '.agentworkforce', 'relay');
    fs.mkdirSync(homeRelay, { recursive: true });
    const store: FleetNodeEnrollmentStore = {
      version: 1,
      active: {},
      nodes: {
        'https://cast.agentrelay.com#ws_default': {
          nodeId: 'node_test123',
          nodeName: 'worker-node-1',
          nodeToken: 'nt_testsecret99999',
          relayWorkspaceId: 'ws_alpha',
          relaycastUrl: 'https://cast.agentrelay.com',
          websocketUrl: 'wss://cast.agentrelay.com/v1/node/ws',
          enrolledAt: '2026-08-01T00:00:00.000Z',
          ...nodes['node_test123'],
        },
      },
    };
    fs.writeFileSync(path.join(homeRelay, 'fleet-enrollments.json'), JSON.stringify(store));
  }

  it('detects a workspace-key.json pin lacking enrolledNodeId while fleet-enrollments.json has entries (#1432)', () => {
    // Project pin exists WITHOUT enrolledNodeId
    setupModernProject({
      workspaceKey: 'rk_live_shadow12345',
      // No enrolledNodeId
    });
    // Global fleet enrollments has 1 active node
    setupFleetEnrollments();

    const result = checkNodeWorkspaceDrift({ cwd, homeDir, env: {} });

    expect(result.status).toBe('WARN');
    const shadowCheck = result.checks.find((c) => c.id === 'pin-shadows-fleet-enrollment');
    expect(shadowCheck).toBeDefined();
    expect(shadowCheck?.status).toBe('WARN');
    expect(shadowCheck?.message).toContain('with no enrolledNodeId, shadowing 1 stored Cloud fleet enrollment(s)');
    expect(shadowCheck?.remediation).toContain('cloud enroll');
    expect(shadowCheck?.remediation).toContain('one-time');
    // Ensure secrets are never printed
    expect(shadowCheck?.message).not.toContain('rk_live_');
  });

  it('detects legacy .agent-relay state left beside .agentworkforce/relay', () => {
    setupModernProject({ workspaceKey: 'rk_live_abc123' });
    setupLegacyProject({ 'stale-data.txt': 'old state' });

    const result = checkNodeWorkspaceDrift({ cwd, homeDir, env: {} });

    expect(result.status).toBe('WARN');
    const legacyCheck = result.checks.find((c) => c.id === 'legacy-project-directory-drift');
    expect(legacyCheck).toBeDefined();
    expect(legacyCheck?.status).toBe('WARN');
    expect(legacyCheck?.message).toContain('Legacy directory .agent-relay exists alongside modern .agentworkforce/relay');
    expect(legacyCheck?.remediation).toContain('Remove stale .agent-relay');
  });

  it('detects legacy project directory when unmigrated (.agent-relay only)', () => {
    setupLegacyProject();

    const result = checkNodeWorkspaceDrift({ cwd, homeDir, env: {} });

    expect(result.status).toBe('WARN');
    const unmigratedCheck = result.checks.find((c) => c.id === 'legacy-project-unmigrated');
    expect(unmigratedCheck).toBeDefined();
    expect(unmigratedCheck?.status).toBe('WARN');
    expect(unmigratedCheck?.remediation).toContain('agent-relay node up');
  });

  it('detects cross-workspace mismatch between repository pin and stored fleet enrollment (#1432)', () => {
    // Pin targets ws_project_different
    setupModernProject({
      workspaceKey: 'rk_live_diff12345',
      enrolledNodeId: 'node_test123',
      workspaceId: 'ws_project_different',
    });
    // Store has node_test123 enrolled under ws_alpha
    setupFleetEnrollments();

    const result = checkNodeWorkspaceDrift({ cwd, homeDir, env: {} });

    expect(result.status).toBe('FAIL');
    const conflictCheck = result.checks.find((c) => c.id === 'pin-workspace-conflict');
    expect(conflictCheck).toBeDefined();
    expect(conflictCheck?.status).toBe('FAIL');
    expect(conflictCheck?.message).toContain('select different workspaces');
    expect(conflictCheck?.message).toContain('workspace ws_project_different');
    expect(conflictCheck?.message).toContain('workspace ws_alpha');
    expect(conflictCheck?.remediation).toContain('agent-relay workspace rebind');
  });

  it('detects incomplete environment enrollment credentials (RELAY_NODE_TOKEN without RELAY_NODE_ID) (#1289)', () => {
    setupModernProject({ workspaceKey: 'rk_live_ok12345' });

    const result = checkNodeWorkspaceDrift({
      cwd,
      homeDir,
      env: {
        RELAY_NODE_TOKEN: 'nt_secrettoken12345',
        // RELAY_NODE_ID missing
      },
    });

    expect(result.status).toBe('FAIL');
    const credCheck = result.checks.find(
      (c) => c.id === 'incomplete-env-credentials-token-without-id'
    );
    expect(credCheck).toBeDefined();
    expect(credCheck?.status).toBe('FAIL');
    expect(credCheck?.message).toContain('RELAY_NODE_ID is required when RELAY_NODE_TOKEN is set');
    // Secret token is redacted
    expect(credCheck?.message).not.toContain('nt_secrettoken12345');
  });

  it('detects pin referencing an enrolledNodeId that is missing in fleet store', () => {
    setupModernProject({
      workspaceKey: 'rk_live_ok12345',
      enrolledNodeId: 'node_nonexistent',
    });
    setupFleetEnrollments(); // has node_test123 only

    const result = checkNodeWorkspaceDrift({ cwd, homeDir, env: {} });

    expect(result.status).toBe('WARN');
    const missingCheck = result.checks.find(
      (c) => c.id === 'pin-enrolled-node-missing-in-store'
    );
    expect(missingCheck).toBeDefined();
    expect(missingCheck?.message).toContain('node_nonexistent');
  });

  it('passes when project pin and fleet enrollment are perfectly aligned', () => {
    setupModernProject({
      workspaceKey: 'rk_live_aligned123',
      enrolledNodeId: 'node_test123',
      workspaceId: 'ws_alpha',
    });
    setupFleetEnrollments(); // node_test123 in ws_alpha

    const result = checkNodeWorkspaceDrift({ cwd, homeDir, env: {} });

    expect(result.status).toBe('PASS');
    expect(result.checks.every((c) => c.status === 'PASS')).toBe(true);
    expect(result.summary).toContain('All node and workspace drift checks passed');
  });
});
