import { describe, expect, it } from 'vitest';
import { explainLog } from '../src/core/explain.js';

describe('explainLog', () => {
  it('explains Issue #1432: pin shadows fleet enrollments warning', () => {
    const log = `
[2026-08-06T10:00:00Z] Starting relay node...
This project is pinned to a workspace with no enrolled node id, so 2 stored Cloud fleet enrollment(s) will be ignored: the broker starts in the pinned workspace and this machine will not serve its Cloud fleet node. Re-run 'relay cloud enroll' from this project to link the pin to a node, or export RELAY_NODE_ID and RELAY_NODE_TOKEN and start with 'relay node up --broker-name <node>'.
Broker started.
`;
    const result = explainLog(log);

    expect(result.status).toBe('WARN');
    const finding = result.findings.find((f) => f.id === 'drift-pin-shadows-fleet-enrollments');
    expect(finding).toBeDefined();
    expect(finding?.status).toBe('WARN');
    expect(finding?.source).toContain('Issue #1432');
    expect(finding?.diagnosis).toContain('pin is missing an enrolledNodeId');
    expect(finding?.remediation).toContain('cloud enroll');
    expect(finding?.remediation).toContain('one-time');
  });

  it('explains Issue #1432: cleared enrolled node on workspace move', () => {
    const log = `
Switching workspace to team-beta...
Cleared this project's enrolled fleet node (node_east_42): it belongs to the workspace you moved away from. Run 'relay cloud enroll' from this project to serve a node in the new workspace.
Workspace switched.
`;
    const result = explainLog(log);

    expect(result.status).toBe('WARN');
    const finding = result.findings.find(
      (f) => f.id === 'drift-cleared-enrolled-node-workspace-move'
    );
    expect(finding).toBeDefined();
    expect(finding?.status).toBe('WARN');
    expect(finding?.diagnosis).toContain('node_east_42');
    expect(finding?.diagnosis).toContain('clearing enrolled fleet node');
  });

  it('explains Issue #1432: cross-workspace conflict error', () => {
    const log = `
Refusing to start: this repository and the stored Fleet enrollment select different workspaces.
  repository pin      /app/.agentworkforce/relay/workspace-key.json -> workspace ws_111
  fleet enrollment    /root/.agentworkforce/relay/fleet-enrollments.json -> workspace ws_222 (node node_999)
Run \`agent-relay workspace rebind <name>\` to repin this project and clear the stale enrolled-node association; alternatively pass --workspace-key or re-enroll this node in the pinned workspace.
`;
    const result = explainLog(log);

    expect(result.status).toBe('FAIL');
    const finding = result.findings.find(
      (f) => f.id === 'drift-cross-workspace-source-conflict'
    );
    expect(finding).toBeDefined();
    expect(finding?.status).toBe('FAIL');
    expect(finding?.diagnosis).toContain('repository pin');
    expect(finding?.remediation).toContain('agent-relay workspace rebind');
  });

  it('explains Issue #1289: incomplete enrollment credentials error', () => {
    const log = `
Error: Cloud enrollment credentials are incomplete: RELAY_NODE_ID is required when RELAY_NODE_TOKEN is set.
Cleaning up failed broker start (pid: 5432)
`;
    const result = explainLog(log);

    expect(result.status).toBe('FAIL');
    const finding = result.findings.find(
      (f) => f.id === 'drift-incomplete-enrollment-credentials'
    );
    expect(finding).toBeDefined();
    expect(finding?.status).toBe('FAIL');
    expect(finding?.diagnosis).toContain('RELAY_NODE_TOKEN is set without RELAY_NODE_ID');
    expect(finding?.remediation).toContain('Export both RELAY_NODE_ID and RELAY_NODE_TOKEN');
  });

  it('explains Issue #1289: failed broker cleanup after enrollment failure', () => {
    const log = `
Failed to stop broker process after Cloud enrollment startup failed (pid: 4242). Run \`agent-relay down --force\` to retry cleanup.
`;
    const result = explainLog(log);

    expect(result.status).toBe('FAIL');
    const finding = result.findings.find((f) => f.id === 'drift-failed-enrollment-cleanup');
    expect(finding).toBeDefined();
    expect(finding?.status).toBe('FAIL');
    expect(finding?.diagnosis).toContain('PID 4242');
    expect(finding?.remediation).toContain('agent-relay down --force');
  });

  it('explains node claim conflict error', () => {
    const log = `
Refusing to start: node node_shared_1 is already served by a live broker on this machine.
  holding broker      pid 1010
`;
    const result = explainLog(log);

    expect(result.status).toBe('FAIL');
    const finding = result.findings.find((f) => f.id === 'drift-node-claim-conflict');
    expect(finding).toBeDefined();
    expect(finding?.status).toBe('FAIL');
    expect(finding?.diagnosis).toContain('node_shared_1');
    expect(finding?.remediation).toContain('agent-relay node down');
  });

  it('explains clean startup log with PASS', () => {
    const log = `
Using persisted Cloud enrollment for node "worker-1" (workspace ws_alpha).
Broker started.
Broker PID: 7777
`;
    const result = explainLog(log);

    expect(result.status).toBe('PASS');
    expect(result.summary).toContain('started cleanly with no drift');
    expect(result.findings[0]?.status).toBe('PASS');
  });

  it('classifies unrecognized or generic error log as UNKNOWN and does not guess', () => {
    const log = `
error: EADDRINUSE: address already in use 0.0.0.0:8080
    at Server.setupListenHandle [as _listen2] (node:net:1898:16)
    at listenInCluster (node:net:1946:12)
`;
    const result = explainLog(log);

    expect(result.status).toBe('UNKNOWN');
    expect(result.summary).toContain('UNKNOWN: No recognizable node/workspace drift patterns found');
    expect(result.findings[0]?.status).toBe('UNKNOWN');
    expect(result.findings[0]?.diagnosis).toContain('will not guess');
  });

  it('redacts secrets in log input before explaining', () => {
    const log = `
Cloud enrollment credentials are incomplete: RELAY_NODE_ID is required when RELAY_NODE_TOKEN is set. Secret: nt_secretlive9988776655
Workspace key: rk_live_supersecretworkspacekey999
`;
    const result = explainLog(log);

    expect(result.status).toBe('FAIL');
    // Ensure raw secrets do NOT appear anywhere in the findings
    const serialized = JSON.stringify(result);
    expect(serialized).not.toContain('nt_secretlive9988776655');
    expect(serialized).not.toContain('rk_live_supersecretworkspacekey999');
    expect(serialized).toContain('[REDACTED_SECRET]');
  });
});
