import { describe, expect, it } from 'vitest';
import { redactSecretsDeep, redactSecretsInString } from '../src/utils/redact.js';

describe('redactSecrets', () => {
  it('redacts various secret token patterns in strings', () => {
    const raw =
      'Tokens: rk_live_abcd1234efgh, nt_mysecretnode123, br_brokersessiontoken99, ocl_node_enr_onetimeenroll123, tok_agenttok12345, arr_resulttoken12345';
    const redacted = redactSecretsInString(raw);

    expect(redacted).not.toContain('rk_live_abcd1234efgh');
    expect(redacted).not.toContain('nt_mysecretnode123');
    expect(redacted).not.toContain('br_brokersessiontoken99');
    expect(redacted).not.toContain('ocl_node_enr_onetimeenroll123');
    expect(redacted).not.toContain('tok_agenttok12345');
    expect(redacted).not.toContain('arr_resulttoken12345');
    expect(redacted).toBe(
      'Tokens: [REDACTED_SECRET], [REDACTED_SECRET], [REDACTED_SECRET], [REDACTED_SECRET], [REDACTED_SECRET], [REDACTED_SECRET]'
    );
  });

  it('redacts sensitive fields in nested objects', () => {
    const obj = {
      workspaceKey: 'rk_live_secret123',
      nodeToken: 'nt_nodesecret456',
      metadata: {
        apiKey: 'br_brokerkey789',
        relaycastApiKey: 'rc_key000',
        normalField: 'safe value',
      },
    };

    const redacted = redactSecretsDeep(obj);

    expect(redacted.workspaceKey).toBe('[REDACTED_SECRET]');
    expect(redacted.nodeToken).toBe('[REDACTED_SECRET]');
    expect(redacted.metadata.apiKey).toBe('[REDACTED_SECRET]');
    expect(redacted.metadata.relaycastApiKey).toBe('[REDACTED_SECRET]');
    expect(redacted.metadata.normalField).toBe('safe value');
  });
});
