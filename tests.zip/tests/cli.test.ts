import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { beforeEach, afterEach, describe, expect, it, vi } from 'vitest';
import { runCli } from '../src/cli.js';

describe('relay-doctor CLI', () => {
  let tempDir: string;
  let cwd: string;
  let homeDir: string;

  beforeEach(() => {
    tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'relay-doctor-cli-'));
    cwd = path.join(tempDir, 'repo');
    homeDir = path.join(tempDir, 'home');
    fs.mkdirSync(cwd, { recursive: true });
    fs.mkdirSync(homeDir, { recursive: true });
  });

  afterEach(() => {
    fs.rmSync(tempDir, { recursive: true, force: true });
    vi.restoreAllMocks();
  });

  it('runs check --cwd and returns WARN on pin shadowing', async () => {
    const modernRelay = path.join(cwd, '.agentworkforce', 'relay');
    fs.mkdirSync(modernRelay, { recursive: true });
    fs.writeFileSync(
      path.join(modernRelay, 'workspace-key.json'),
      JSON.stringify({ workspaceKey: 'rk_live_testpin123' })
    );

    const homeRelay = path.join(homeDir, '.agentworkforce', 'relay');
    fs.mkdirSync(homeRelay, { recursive: true });
    fs.writeFileSync(
      path.join(homeRelay, 'fleet-enrollments.json'),
      JSON.stringify({
        version: 1,
        active: {},
        nodes: {
          n1: {
            nodeId: 'n1',
            nodeName: 'worker',
            nodeToken: 'nt_secret',
            relayWorkspaceId: 'ws_1',
            relaycastUrl: 'https://cast.agentrelay.com',
            websocketUrl: 'wss://cast.agentrelay.com/v1/node/ws',
            enrolledAt: '2026-08-01T00:00:00.000Z',
          },
        },
      })
    );

    const logSpy = vi.spyOn(console, 'log').mockImplementation(() => {});

    const exitCode = await runCli(['check', '--cwd', cwd, '--home', homeDir]);

    expect(exitCode).toBe(0); // WARN exits 0
    const output = logSpy.mock.calls.map((c) => c.join(' ')).join('\n');
    expect(output).toContain('[WARN]');
    expect(output).toContain('pin-shadows-fleet-enrollment');
    expect(output).not.toContain('rk_live_testpin123');
  });

  it('runs explain --input <file> and outputs findings', async () => {
    const logFile = path.join(tempDir, 'sample.log');
    fs.writeFileSync(
      logFile,
      'Refusing to start: this repository and the stored Fleet enrollment select different workspaces.'
    );

    const logSpy = vi.spyOn(console, 'log').mockImplementation(() => {});

    const exitCode = await runCli(['explain', '--input', logFile]);

    expect(exitCode).toBe(1); // FAIL exits 1
    const output = logSpy.mock.calls.map((c) => c.join(' ')).join('\n');
    expect(output).toContain('[FAIL]');
    expect(output).toContain('Issue #1432: Repository Pin and Fleet Enrollment Conflict');
  });

  it('runs explain on unrecognized error and outputs UNKNOWN without guessing', async () => {
    const logSpy = vi.spyOn(console, 'log').mockImplementation(() => {});

    const exitCode = await runCli(['explain', '--input', 'SyntaxError: Unexpected token < in JSON at position 0']);

    expect(exitCode).toBe(2); // UNKNOWN exits 2
    const output = logSpy.mock.calls.map((c) => c.join(' ')).join('\n');
    expect(output).toContain('[UNKNOWN]');
    expect(output).toContain('will not guess');
  });

  it('runs check and explain against static disk fixtures in tests/fixtures', async () => {
    const fixtureCwd = path.join(__dirname, 'fixtures', 'synthetic', 'pin-shadowing');
    const fixtureHome = path.join(fixtureCwd, 'home');
    const logSpy = vi.spyOn(console, 'log').mockImplementation(() => {});

    const checkExit = await runCli(['check', '--cwd', fixtureCwd, '--home', fixtureHome]);
    expect(checkExit).toBe(0);

    const logPath = path.join(__dirname, 'fixtures', 'synthetic', 'logs', 'shadow-warning.log');
    const explainExit = await runCli(['explain', '--input', logPath]);
    expect(explainExit).toBe(0);

    const unknownLogPath = path.join(__dirname, 'fixtures', 'synthetic', 'logs', 'unknown-error.log');
    const unknownExit = await runCli(['explain', '--input', unknownLogPath]);
    expect(unknownExit).toBe(2);
  });
});
