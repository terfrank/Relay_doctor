import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { beforeEach, afterEach, describe, expect, it, vi } from 'vitest';
import { checkNodeWorkspaceDrift, resolveRelayHome, resolveLegacyHomeCandidates } from '../src/core/check.js';
import { runCli } from '../src/cli.js';

describe('Hardening & Robustness', () => {
  let tempDir: string;
  let cwd: string;
  let homeDir: string;

  beforeEach(() => {
    tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'relay-doctor-harden-'));
    cwd = path.join(tempDir, 'project');
    homeDir = path.join(tempDir, 'home');
    fs.mkdirSync(cwd, { recursive: true });
    fs.mkdirSync(homeDir, { recursive: true });
  });

  afterEach(() => {
    fs.rmSync(tempDir, { recursive: true, force: true });
    vi.restoreAllMocks();
  });

  describe('1. Secret leak on corrupt JSON', () => {
    it('never prints raw secret or Node syntax error snippet when workspace-key.json is corrupt (text & json)', async () => {
      const modernRelay = path.join(cwd, '.agentworkforce', 'relay');
      fs.mkdirSync(modernRelay, { recursive: true });

      // Intentionally invalid JSON that includes sensitive credentials
      const corruptPinContent = '{\n  "workspaceKey": "rk_live_topsecret_TEST_1234567890",\n  "nodeToken": "nt_secretnode_TEST_9988776655",\n  invalid_syntax\n';
      fs.writeFileSync(path.join(modernRelay, 'workspace-key.json'), corruptPinContent);

      // Also create a corrupt fleet-enrollments.json with secrets
      const homeRelay = path.join(homeDir, '.agentworkforce', 'relay');
      fs.mkdirSync(homeRelay, { recursive: true });
      const corruptFleetContent = '{\n  "nodes": { "rk_live_fake": "nt_secretnode_TEST_extra",\n  broken';
      fs.writeFileSync(path.join(homeRelay, 'fleet-enrollments.json'), corruptFleetContent);

      // Test 1: Human-readable text output via runCli
      const textLogs: string[] = [];
      const textLogSpy = vi.spyOn(console, 'log').mockImplementation((...args: any[]) => {
        textLogs.push(args.join(' '));
      });

      const textExit = await runCli(['check', '--cwd', cwd, '--home', homeDir]);
      expect(textExit).toBe(1); // FAIL exit code

      const textOutput = textLogs.join('\n');
      expect(textOutput).not.toContain('rk_live_topsecret_TEST');
      expect(textOutput).not.toContain('nt_secretnode_TEST');
      expect(textOutput).toContain('Workspace pin file is not valid JSON or cannot be read');
      expect(textOutput).toContain('Fleet enrollment store file is not valid JSON or cannot be read');
      textLogSpy.mockRestore();

      // Test 2: JSON output via runCli
      const jsonLogs: string[] = [];
      const jsonLogSpy = vi.spyOn(console, 'log').mockImplementation((...args: any[]) => {
        jsonLogs.push(args.join(' '));
      });

      const jsonExit = await runCli(['check', '--cwd', cwd, '--home', homeDir, '--json']);
      expect(jsonExit).toBe(1);

      const jsonOutput = jsonLogs.join('\n');
      expect(jsonOutput).not.toContain('rk_live_topsecret_TEST');
      expect(jsonOutput).not.toContain('nt_secretnode_TEST');
      const parsedJson = JSON.parse(jsonOutput);
      expect(parsedJson.status).toBe('FAIL');
      jsonLogSpy.mockRestore();
    });

    it('redacts secrets when an unknown command is passed to cli', async () => {
      const errLogs: string[] = [];
      const errSpy = vi.spyOn(console, 'error').mockImplementation((...args: any[]) => {
        errLogs.push(args.join(' '));
      });
      const logSpy = vi.spyOn(console, 'log').mockImplementation(() => {});

      const exitCode = await runCli(['rk_live_secret_command_TEST']);
      expect(exitCode).toBe(1);

      const errOutput = errLogs.join('\n');
      expect(errOutput).not.toContain('rk_live_secret_command_TEST');
      expect(errOutput).toContain('[REDACTED_SECRET]');
      errSpy.mockRestore();
      logSpy.mockRestore();
    });
  });

  describe('2. Guard against invalid fleet-enrollments.json structures', () => {
    function writeFleet(content: string) {
      const homeRelay = path.join(homeDir, '.agentworkforce', 'relay');
      fs.mkdirSync(homeRelay, { recursive: true });
      fs.writeFileSync(path.join(homeRelay, 'fleet-enrollments.json'), content);
    }

    it('rejects fleet-enrollments.json when root is null', () => {
      writeFleet('null');
      const result = checkNodeWorkspaceDrift({ cwd, homeDir, env: {} });
      expect(result.status).toBe('FAIL');
      const check = result.checks.find((c) => c.id === 'fleet-store-invalid-format');
      expect(check).toBeDefined();
      expect(check?.message).toContain('expected a JSON object');
    });

    it('rejects fleet-enrollments.json when root is an array', () => {
      writeFleet('[1, 2, 3]');
      const result = checkNodeWorkspaceDrift({ cwd, homeDir, env: {} });
      expect(result.status).toBe('FAIL');
      const check = result.checks.find((c) => c.id === 'fleet-store-invalid-format');
      expect(check?.message).toContain('expected a JSON object');
    });

    it('rejects fleet-enrollments.json when root is a string', () => {
      writeFleet('"just a string"');
      const result = checkNodeWorkspaceDrift({ cwd, homeDir, env: {} });
      expect(result.status).toBe('FAIL');
      const check = result.checks.find((c) => c.id === 'fleet-store-invalid-format');
      expect(check?.message).toContain('expected a JSON object');
    });

    it('rejects fleet-enrollments.json when root is a number', () => {
      writeFleet('42');
      const result = checkNodeWorkspaceDrift({ cwd, homeDir, env: {} });
      expect(result.status).toBe('FAIL');
      const check = result.checks.find((c) => c.id === 'fleet-store-invalid-format');
      expect(check?.message).toContain('expected a JSON object');
    });

    it('rejects fleet-enrollments.json when nodes property is missing', () => {
      writeFleet('{"version": 1}');
      const result = checkNodeWorkspaceDrift({ cwd, homeDir, env: {} });
      expect(result.status).toBe('FAIL');
      const check = result.checks.find((c) => c.id === 'fleet-store-invalid-format');
      expect(check?.message).toContain('`nodes` must be a JSON object');
    });

    it('rejects fleet-enrollments.json when nodes is null', () => {
      writeFleet('{"version": 1, "nodes": null}');
      const result = checkNodeWorkspaceDrift({ cwd, homeDir, env: {} });
      expect(result.status).toBe('FAIL');
      const check = result.checks.find((c) => c.id === 'fleet-store-invalid-format');
      expect(check?.message).toContain('`nodes` must be a JSON object');
    });

    it('rejects fleet-enrollments.json when nodes is an array', () => {
      writeFleet('{"version": 1, "nodes": ["not-an-object"]}');
      const result = checkNodeWorkspaceDrift({ cwd, homeDir, env: {} });
      expect(result.status).toBe('FAIL');
      const check = result.checks.find((c) => c.id === 'fleet-store-invalid-format');
      expect(check?.message).toContain('`nodes` must be a JSON object');
    });

    it('rejects fleet-enrollments.json when nodes is a number or primitive', () => {
      writeFleet('{"version": 1, "nodes": 123}');
      const result = checkNodeWorkspaceDrift({ cwd, homeDir, env: {} });
      expect(result.status).toBe('FAIL');
      const check = result.checks.find((c) => c.id === 'fleet-store-invalid-format');
      expect(check?.message).toContain('`nodes` must be a JSON object');
    });
  });

  describe('3. Guard against invalid workspace-key.json structures', () => {
    function writePin(content: string) {
      const modernRelay = path.join(cwd, '.agentworkforce', 'relay');
      fs.mkdirSync(modernRelay, { recursive: true });
      fs.writeFileSync(path.join(modernRelay, 'workspace-key.json'), content);
    }

    it('rejects workspace-key.json when root is null', () => {
      writePin('null');
      const result = checkNodeWorkspaceDrift({ cwd, homeDir, env: {} });
      expect(result.status).toBe('FAIL');
      const check = result.checks.find((c) => c.id === 'workspace-pin-invalid-format');
      expect(check).toBeDefined();
      expect(check?.message).toContain('expected a JSON object');
    });

    it('rejects workspace-key.json when root is an array', () => {
      writePin('[]');
      const result = checkNodeWorkspaceDrift({ cwd, homeDir, env: {} });
      expect(result.status).toBe('FAIL');
      const check = result.checks.find((c) => c.id === 'workspace-pin-invalid-format');
      expect(check?.message).toContain('expected a JSON object');
    });

    it('rejects workspace-key.json when workspaceKey is missing', () => {
      writePin('{"enrolledNodeId": "node_1"}');
      const result = checkNodeWorkspaceDrift({ cwd, homeDir, env: {} });
      expect(result.status).toBe('FAIL');
      const check = result.checks.find((c) => c.id === 'workspace-pin-missing-key');
      expect(check).toBeDefined();
      expect(check?.message).toContain('missing a valid "workspaceKey"');
    });

    it('rejects workspace-key.json when workspaceKey is empty whitespace', () => {
      writePin('{"workspaceKey": "   "}');
      const result = checkNodeWorkspaceDrift({ cwd, homeDir, env: {} });
      expect(result.status).toBe('FAIL');
      const check = result.checks.find((c) => c.id === 'workspace-pin-missing-key');
      expect(check).toBeDefined();
    });
  });

  describe('4. Home directory resolution logic', () => {
    it('prioritizes AGENT_RELAY_HOME override', () => {
      const customHome = path.join(tempDir, 'custom-relay-home');
      const resolved = resolveRelayHome(homeDir, { AGENT_RELAY_HOME: customHome });
      expect(resolved).toBe(path.resolve(customHome));
    });

    it('prioritizes AGENT_RELAY_DATA_DIR override when AGENT_RELAY_HOME is unset', () => {
      const customData = path.join(tempDir, 'custom-relay-data');
      const resolved = resolveRelayHome(homeDir, { AGENT_RELAY_DATA_DIR: customData });
      expect(resolved).toBe(path.resolve(customData));
    });

    it('uses Windows APPDATA path on win32', () => {
      const appData = path.join(tempDir, 'Roaming');
      const expected = path.join(appData, 'agentworkforce', 'relay');
      fs.mkdirSync(expected, { recursive: true });

      const resolved = resolveRelayHome(homeDir, { APPDATA: appData }, 'win32');
      expect(resolved).toBe(expected);
    });

    it('uses Linux XDG_DATA_HOME path on linux', () => {
      const xdgData = path.join(tempDir, 'xdg-share');
      const expected = path.join(xdgData, 'agentworkforce', 'relay');
      fs.mkdirSync(expected, { recursive: true });

      const resolved = resolveRelayHome(homeDir, { XDG_DATA_HOME: xdgData }, 'linux');
      expect(resolved).toBe(expected);
    });

    it('uses macOS Application Support path on darwin', () => {
      const expected = path.join(homeDir, 'Library', 'Application Support', 'agentworkforce', 'relay');
      fs.mkdirSync(expected, { recursive: true });

      const resolved = resolveRelayHome(homeDir, {}, 'darwin');
      expect(resolved).toBe(expected);
    });

    it('detects legacy home paths under XDG or APPDATA', () => {
      const appData = path.join(tempDir, 'Roaming');
      const legacyWindows = path.join(appData, 'agent-relay');
      fs.mkdirSync(legacyWindows, { recursive: true });

      const detected = resolveLegacyHomeCandidates(homeDir, { APPDATA: appData }, 'win32');
      expect(detected).toContain(legacyWindows);
    });
  });
});
